package com.example.springwebdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwebdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
